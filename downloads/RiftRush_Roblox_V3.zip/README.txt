RIFT RUSH — NEON HUNTERS (ROBLOX EDITION)

This is an original Roblox adaptation of the Rift Rush browser game.

CONTROLS
- PC: WASD, arrow keys or ZQSD to move; Space to dash.
- Mobile/tablet: Roblox thumb stick to move; DASH button on the right.
- Gamepad: left stick to move; B to dash.
- Weapons aim and fire automatically.
- HELP and SETTINGS are available from the main menu and pause screen.
- Keyboard controls can be rebound and sound volume has Low/Medium/High modes.

GAME LOOP
- Survive the neon swarm.
- Collect Rift Shards and choose upgrades.
- The Rift Titan appears near the end of the two-minute run.
- Defeat it before time expires.

HOW TO OPEN
1. In Roblox Studio choose File > Open from File.
2. Select RiftRush_Neon_Hunters_V3.rbxlx.
3. Press Play to test it.
4. Choose File > Publish to Roblox As... to create the online experience.

No paid assets or Robux are required. All art is generated procedurally from Roblox parts and UI elements.
